'''
سلام.وقت شما بخیر.این کد پروژه ای هستش که شما از ما خواسته بودید.فقط خواستم یه توضیح مختصری بدم.اونم اینکه این کد توی خط 78 یه مشکلی داره
و موقع ران کردن ارور میده و شما باید یکبار دیگه ران کنید تا برنامه اجرا بشه.
 و اینکه تو انجام بخشی از  پروژه از یکی دو نفر کمک گرفتم .با تشکر از شما.

'''


import random 
from game import Person 
from game import bcolors 
from magic import Spell 
from inventory import Item 



potion = Item("Potion", "potion", "Heals 50 HP", 50) 

elixer = Item("Elixer", "elixer", "Fully restores HP/MP", 9999)  

grenade = Item("Grenade", "attack", "Deals 500 damage", 500) 



fire = Spell("Fire", 25, 600) 
thunder = Spell("Thunder", 25, 600)   
blizzard = Spell("Blizzard", 25, 600)  
meteor = Spell("Meteor", 40, 1200) 


player_items = [
    {"item": elixer, "quantity": 5 },
    {"item": potion, "quantity": 15},
    {"item": grenade,"quantity": 5 },
]

player_spells = [fire, thunder, blizzard, meteor]



enemy1 = Person("bad_Enemy ", 1250, 130, 560, [], [])
enemy2 = Person("Real_Enemy", 1250, 130, 560, [], [])
enemy3 = Person("Fake_Enemy", 1250, 130, 560, [], [])


player1 = Person("Homayun", 3260, 132, 300, player_spells, player_items)
player2 = Person("Alierza", 3260, 132, 300, player_spells, player_items)
player3 = Person("Jesus  ", 3260, 132, 300, player_spells, player_items)


enemies = [enemy1, enemy2, enemy3]

players = [player1, player2, player3]


ready = True
print("It's showtime!!Let's Start it dudes!!!\n")


while ready:
    print("××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××\n\n")
   
    print("Name of warriors:        *HP*                                    *MP*\n")

   
    for player in players:
        player.get_stats() 
   
    for enemy in enemies:
        enemy.get_enemy_stats() 

    for player in players:
        if player.get_hp() == 0:
                pass

        
        player.choose_action()
        choice = input(f"{player.name}, choose your action: ")
        index = int(choice) -1

        if index == 0:  
            target = player.choose_target(enemies)  
            dmg = player.generate_damage()  
            enemies[target].take_damage(dmg)
           
            print(f"{player.name} attacks {enemies[target].name} for {dmg} points of damage.")

            if enemies[target].get_hp() == 0:  
                print(f"{enemies[target].name} has been defeated!")
                enemies.pop(target)  

        elif index == 1: 
            player.choose_magic()  
            magic_choice = int(input("Choose magic: ")) - 1  

            spell = player.magic[magic_choice] 
            magic_dmg = spell.generate_damage()  
            current_mp = player.get_mp() 

            if (spell.cost > current_mp):  
                print("Not enough MP :(")
                continue

            player.reduce_mp(spell.cost) 
            target = player.choose_target(enemies) 
            enemies[target].take_damage(magic_dmg)  
            print(f"{spell.name} deals {magic_dmg} points of damage to {enemies[target].name}")

            if enemies[target].get_hp() == 0:  
                print(f"{enemies[target].name} has been defeated!")
                enemies.pop(target)

        elif index == 2:  
            player.choose_item() 
            item_choice = int(input("    Choose item: ")) - 1 

            item = player.items[item_choice]["item"]

            if player.items[item_choice]["quantity"] == 0: 
                print("your out of it... Choose another item.")
                continue

            player.items[item_choice]["quantity"] -= 1  

            if item.type == "attack":
                target = player.choose_target(enemies)  
                enemies[target].take_damage(item.prop) 
             
                print(f"{item.name} deals {item.prop} points of damage to {enemies[target].name}")
           

            elif   item.type == "potion":
                player.heal(item.prop)  
               
                print(f"{item.name} heals {player.name} for {item.prop} HP.")


            elif item.type == "elixer":
                player.hp = player.maxhp 
                player.mp = player.maxmp
                print(f"{item.name} restore HP/MP of {player.name}.")


                if enemies[target].get_hp() == 0: 
                    print(f"{enemies[target].name} has been defeated!")
                    enemies.pop(target)

  
    if len(enemies) == 0: 
        print("Enemies are dead !!")
        running = False
        break

    for enemy in enemies:
        if enemy.get_hp() == 0:  
           pass

        target = random.choice(players)
        while target.get_hp() == 0: 
            target = random.choice(players)

        enemy_dmg = enemy.generate_damage()  
        target.take_damage(enemy_dmg)  
        print(f"{enemy.name} attacks {target.name} for {enemy_dmg} points of damage.")

        if target.get_hp() == 0:
            print(f"{target.name} has been defeated!")

   
    defeated_players = sum(1 for player in players if player.get_hp() == 0)
    if defeated_players >= 2:  
        print("You've been slaughtered amigo!")
        running = False
        break
